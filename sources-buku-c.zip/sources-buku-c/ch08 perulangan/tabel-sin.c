/* tabel-sin.c
 * Program membuat tabel fungsi sin(x)  
 * untuk x = 0...1, sebanyak 11 baris 
 */
#include<stdio.h>
#include<math.h>

int main()
{
   int i, n;
   float s;  	// menampung nilai fungsi sinus
   float x;  	// sudut dalam radian
   float dx; 	// penambahan sudut
   
   n = 10;
   dx = 0.1;

   printf("---------------------\n");      
   printf("NO     X      SIN(X)\n");
   printf("=====================\n");
   for(i = 0; i <= n; i++){
      x = i*dx;
      s = sin(x);
      printf("%d  %f  %f \n", i, x, s);
   }   
   printf("---------------------\n");      
   
   return 0;
}
