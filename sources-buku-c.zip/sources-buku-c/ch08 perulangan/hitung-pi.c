/*  hitung-pi.c 
 *  Menghitung bilangan pi 
 */
 
#include<stdio.h>

int main()
{
	long n;
	double x, s; // x bilangan ganjil, s jumlah suku
	double ds;   // ds = 1/x
    
	s = 0.0;
	ds = 1;
	n = 1;
	while(ds > 1.0E-6){
		x = (2*n - 1);  // bilangan ganjil
		ds = 1.0/x;		
		if(n%2 == 0) s = s - ds; // suku genap negatif
		else s = s + ds;         // suku ganjil positif
		printf("%12.10lf\n",4*s);
		n++;
	}
	
	return 0;
}
