/*  sum-for.c
 *  Program menghitung s = 1+2+...+100 
 */
#include<stdio.h>

int main()
{
   int i;
   long int s;  	// jumlah s
   
   s = 0;
   for(i = 1; i <= 100; i++){
      s = s + i; 					// dapat ditulis: s += i; 
      printf("%d   %ld\n", i, s);  	// cetak nilai i dan s
   }   
   
   return 0;
}
