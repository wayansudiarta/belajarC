/*  banding-float.c
 *  Program membandingkan dua float 
 */
#include<stdio.h>

int main()
{
   float s;  	
   
   s = 0;
   do{
      s = s + 1/3.0;			// dapat ditulis: s += 1/3.0; 
      printf("%f\n", s);  	// cetak hasil
   }while(s != 3);       // berhenti ketika s == 3
   
   return 0;
}
