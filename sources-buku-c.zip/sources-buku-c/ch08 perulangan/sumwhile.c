/* Program menghitung s = 1+2+...+100 
 */
#include<stdio.h>

int main()
{
   int i;
   long int s;  	// jumlah s
   
   i = 1;
   s = 0;
   while(i <= 100){
      s = s + i; 					// dapat ditulis: s += i; 
      printf("%d   %ld\n", i, s);  	// cetak hasil
      i++;
   }   
   
   return 0;
}