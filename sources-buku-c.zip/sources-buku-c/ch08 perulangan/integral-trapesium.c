/*  integral-trapesium.c
 *  Program menghitung integral secara numerik
 *  $\int_a^b f(x) dx$ dengan metode trapesium
 *  f(x) = sin(x)
 */
#include<stdio.h>
#include<math.h>

int main()
{
	int i, N = 100;		// indeks dan jumlah data
	double a, b;			// batas integral
	double h, f, x;		// interval, fungsi f(x) dan posisi x
	double sum;				// jumlah
	double pi = 2.0*asin(1.0);	// bilangan pi

	a = 0;
	b = pi;
	h = (b-a)/(double) N;
	
	sum = 0;
	for(i = 1; i < N; i++){
		x = a + i*h;
		f = sin(x);
		sum = sum + f;		// dapat ditulis: s += f; 
	}   
	sum = h*(0.5*sin(a) + sum + 0.5*sin(b));
	printf("Nilai integral sin(x) = %lf\n", sum);
       
	return 0;
}
