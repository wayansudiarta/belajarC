/*   triplet9.c
 *   Program menentukan tiga bilangan bulat positif
 *   yang berjumlah sama dengan 9
 */
 
#include<stdio.h>
 
int main()
{
	int i, j, k;
	int n = 0;

	for(i = 1; i <= 9; i++){
		for(j = 1; j <= 9; j++){
			for(k = 1; k <= 9; k++){
				if(i + j + k == 9){
					n++;
					printf(" %d  %d  %d \n", i, j, k);   
				}
			}
		}
	}    
 
	printf(" Jumlah triplet = %d", n);
	
	return 0;
 }
 