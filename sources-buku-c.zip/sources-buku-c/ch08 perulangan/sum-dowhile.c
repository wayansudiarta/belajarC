/*  sum-dowhile.c
 *  Program menghitung s = 1+2+...+100 
 */
#include<stdio.h>

int main()
{
   int i;
   long int s;  	// jumlah s
   
   i = 1;
   s = 0;
   do{
      s = s + i; 					// dapat ditulis: s += i; 
      printf("%d   %ld\n", i, s);  	// cetak hasil
      i++;
   }while(i <= 100);   
   
   return 0;
}
