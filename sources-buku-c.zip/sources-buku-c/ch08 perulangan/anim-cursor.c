/* anim-cursor.c
 * Cursor yang berputar 
 * fungsi yang digunakan: fflush() dan usleep()
 */

#include <stdio.h>

int main()
{
	printf(" Mohon tunggu sebentar -");  
	while (1) {
		usleep(200000);
		printf("\b\\");  fflush(stdout);
		usleep(200000);
		printf("\b|");  fflush(stdout);
		usleep(200000);
		printf("\b/");  fflush(stdout);
		usleep(200000);
		printf("\b-");  fflush(stdout);
	}

	return 0;
}
