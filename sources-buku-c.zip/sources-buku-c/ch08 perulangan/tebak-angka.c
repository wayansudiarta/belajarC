/* tebak-angka.c
 * Program tebak angka 0 ... 9 
 */

#include <stdio.h>
#include <stdlib.h>  // library untuk fungsi rand() 

int main()
{
	int angka, tebakan;

	do{
		// pilih angka acak
		angka = rand()%10;
		printf("Masukan tebakan anda");
		printf("Ketik 0...9, atau -1 (berhenti) :");
		scanf("%d", &tebakan);
 
		if(tebakan == angka) printf("WOW anda hebat\n\n");
		else if(tebakan != -1) printf("Sabar ya, coba lagi \n\n");
    
	}while(tebakan != -1);

	printf("\n Terimakasih anda sudah mencoba game tebak angka \n");

	return 0;
}
