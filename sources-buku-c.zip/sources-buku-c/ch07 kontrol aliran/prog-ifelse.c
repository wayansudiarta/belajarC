/* prog-ifelse.c
 * Menentukan bilangan ganjil/genap
 * Menggunakan operasi sisa bagi %
 */

#include<stdio.h>

int main()
{
	int x;
   
	printf("Masukkan bilangan bulat x:\n");
	scanf("%d",&x);

	if((x % 2) == 0){ 
		printf("x adalah bilangan genap \n");
    }else{
		printf("x adalah bilangan ganjil \n");
	}
	
	return 0;
}
