/* konversi-nilai.c
 * Mengubah nilai angka ke nilai huruf sesuai
 * Tabel berikut ini.
 * \geq = greater equal, \leq = less equal 
 * $NA \geq 80$  &  A \\
 * $ 72 \leq NA < 80$  &  B+ \\
 * $ 65 \leq NA < 72$  &  B \\
 * $ 60 \leq NA < 65$  &  C+ \\
 * $ 56 \leq NA < 60$  &  C \\
 * $ 50 \leq NA < 56$  &  D+ \\
 * $ 46 \leq NA < 50$  &  D \\
 * $ NA < 46$  &  E \\
 *
 *
 */
#include<stdio.h>

int main()
{
	float x;			// menampung nilai angka
	char na;			// nilai akhir dalam huruf
	
	printf("Masukan nilai dalam angka, x? ");
	scanf("%f",&x);
	
	if(x >= 80){
		printf("Nilai adalah A\n");
	}else if(x >= 72){
		printf("Nilai adalah B+\n");
	}else if(x >= 65){
		printf("Nilai adalah B\n");
	}else if(x >= 60){
		printf("Nilai adalah C+\n");
	}else if(x >= 56){
		printf("Nilai adalah C\n");
	}else if(x >= 50){
		printf("Nilai adalah D+\n");
	}else if(x >= 46){
		printf("Nilai adalah D\n");
	}else{
		printf("Nilai adalah E\n");
	}
	
	return 0;
}
