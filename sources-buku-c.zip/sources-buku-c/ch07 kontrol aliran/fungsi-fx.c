/* fungsi-fx.c
 * Menentukan nilai fungsi f(x)
 */
#include<stdio.h>

int main()
{
	float x;			// menampung akar-akar
	float f;			// nilai f(x)
	
	printf("Masukan nilai x?");
	scanf("%f",&x);
	
	if(x < 0){
		f = 0.0;
	}else if(x < 1){
		f = 3.0*x;
	}else{
		f = 3.0;
	}

	printf(" Nilai f(x) = %f\n", f);
	
	return 0;
}
