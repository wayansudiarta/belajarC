/* akar-kuadrat.c
 * Menentukan akar persamaan kuadrat
 * ax^2 + bx + c = 0
 */
#include<stdio.h>
#include<math.h>

int main()
{
	float a, b, c;		// parameter persamaan kuadrat
	float d;					// discriminan d = b^2 - 4ac
	float x1, x2;			// menampung akar-akar
	float t;					// variabel sementara
	
	printf("Masukan parameter persamaan kuadrat \n");
	printf("ax^2 + bx + c = 0\n");
	printf("Nilai a?");
	scanf("%f",&a);
	printf("Nilai b?");
	scanf("%f",&b);
	printf("Nilai c?");
	scanf("%f",&c);
	
	//hitung nilai descriminan
	d = b*b - 4*a*c;

	if(d > 0){
		t = sqrt(d);
		x1 = (-b + t)/(2*a);
		x2 = (-b - t)/(2*a);
		printf("\nAda dua akar yaitu:\n");
		printf(" x1 = %f\n", x1);
		printf(" x2 = %f\n", x2);
	}else if(d < 0){
		printf("\nTidak ada akar\n");
	}else{
		x1 = -b/(2*a);
		printf("\nAda satu akar yaitu:\n");
		printf(" x1 = %f\n", x1);
	}
	
	return 0;
}
