/* prog-ifelseif.c
 * Menentukan bilangan lebih kecil/besar dari atau sama dengan 5
 */

#include<stdio.h>

int main()
{
	float x;
   
	printf("Masukkan nilai x:\n");
	scanf("%f",&x);

	if(x < 5.0){ 
		printf("x lebih kecil dari 5.0 \n");
    }else if(x > 5.0){
		printf("x lebih besar dari 5.0 \n");
	}else{
		printf("x sama dengan 5.0 \n");
	}
	
	return 0;
}
