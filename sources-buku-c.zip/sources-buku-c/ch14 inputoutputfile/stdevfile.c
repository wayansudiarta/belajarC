/*
	stdevfile.c
	Merupakan program untuk membaca sebuah fille dan enentukan nilai 
	standar deviasinya, kemudian menambahkan nilai hasil keluaran kedalam file tersebut
	
	 Source = http://www.sanfoundry.com/c-programming-examples.
	
	Untuk mengkompilasinya menggunakan cara :
	gcc stdevfile.c -o stdevfile
	
	dan untuk menjalankanya menggunakan: 
	./stdevfile.exe
*/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>


double stdev(FILE *input, double mean);

int main(){
	
	// (1) inisidalisasi fungsi untuk mengakses file
	FILE *save;
	
	double data,stddev,sum = 0,n=0;
	
	// (2) membuka file dan proses perhitungan rata-rata dan menampilkan hasil
	save = fopen("sum2.txt","r");
	
	while (!feof(save)){
		
		fscanf(save,"%lf",&data);
		sum = sum + data;
		n=n+1;
	}
	
	sum = sum/n;
	
	fclose(save);
	
	save = fopen("sum2.txt","r");
	
	stddev = stdev(save,sum);
	
	fclose(save);
	
	save = fopen("sum2.txt","a");
	
	fprintf(save,"\n\nStndar deviasi seluruh data = %lf",stddev);
	
	fclose(save);
	
	return 0;
}

// (3)  fungsi untuk menghitung nilai standar deviasi
double stdev(FILE *input, double mean){
	
	double datasave,n,jumlah,kuadrat;
	
	n = 0;
	jumlah = 0;
	
	while(!feof(input)){
		
		fscanf(input,"%lf",&datasave);
		jumlah += pow((datasave - mean),2);
		n+=1;
	}
	
	
	
	return sqrt(jumlah/(n-1));
}
