/*
	fileregresi.c
	Merupakan kode program mengabil nilai dari dua file berbedan kemudian ditentukan regresinya
	
	Untuk kompilasi kode program ini menggunakan:
	gcc fileregresi.c -o fileregresi
	
	dan untuk menjalankan program ini :
	./fileregresi.exe
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>


int main(){
	
	// (1) deklarasi variabel untuk kedua file dan inisialisasi variabel lainya
	FILE *save1 , *save2;
	
	double data1,data2,n=0;
	
	double sx = 0.0,sy = 0.0, sx2 = 0.0, sy2 = 0.0, sxy = 0.0;
	double temp;
	double m,b;
	
	// (2) membuka kedua file dan menempatkan kedua kedalam variable yang telah dideklarasikan
	save1 = fopen("sumx.txt","r");
	save2 = fopen("sumy.txt","r");
	
	while (!feof(save1)&&!feof(save2)){
		
		fscanf(save1,"%lf",&data1);
		fscanf(save2,"%lf",&data2);
		
		sx += data1;
		sx2 += data1*data1;
		sy += data2;
		sy2 += data2*data2;
		sxy += data1*data2;
		n=n+1;
	}
	
	// (3) proses perhitungan nilai regresi dari kedua file
	temp = n*sx2 - sx*sx;
	
	if (fabs(temp) < 1.0E-10){
		m=0;
		b=0;
	}
	
	m = (n*sxy - sx*sy)/temp;
	b = (sy*sx2 - sx*sxy)/temp;
	
	fclose(save1);
	fclose(save2);
	
	// (4) menampilkan keluaran berupa  nilai slope dan intercept
	printf ("Nilai m = %.2lf\n",m);	
	printf ("Nilai b = %.2lf\n",b);
	
	printf ("\nPersamaan regresinya = \n");
	printf ("Y = %.2lf + %.2lfX",m,b);
	
	
	
	return 0;
}

