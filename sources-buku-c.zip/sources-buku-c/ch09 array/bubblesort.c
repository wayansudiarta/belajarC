/*
 * bubblesort.c
   Program bublesort untuk memsortir nilai suatu array dari yang terkecil sampai nilai paling besar
   
   Source = http://www.sanfoundry.com/c-programming-examples.
   
   Untuk kompilasi kode ini dengan cara:
   gcc bubblesort.c -o bubblesort
   
   dan untuk menjalankan programnya menggunakan:
   ./bubblesort.exe
 */
 
#include <stdio.h>
#define MAXSIZE 10
 
void main()
{
    int array[MAXSIZE];
    int i, j, num, temp;
 	
    printf("Masukan Jumlah Array MAX 10 \n");
    scanf("%d", &num);
    printf("Masukan elemen array satu per satu \n");
    
	// (1) Memasukan array yang disortir
    for (i = 0; i < num; i++){
        scanf("%d", &array[i]);
    }
    printf("\nArray yang dimasukan adalah... \n");
    
    for (i = 0; i < num; i++){
        printf("%d\n", array[i]);
    }
    
    // (2) Memulai mensortir masukan yang diberikan dari nilai terkecil ke besar
    for (i = 0; i < num; i++){
    	
        for (j = 0; j < (num - i - 1); j++){
        	
            if (array[j] > array[j + 1]){
                temp = array[j];
                array[j] = array[j + 1];
                array[j + 1] = temp;
            }
        }
    }
    
    // (3) menampikan hasil sortiran.
    printf("\nHasil Sortir Array...\n");
    
    for (i = 0; i < num; i++){
        printf("%d\n", array[i]);
    }
    
    return 0;
}
