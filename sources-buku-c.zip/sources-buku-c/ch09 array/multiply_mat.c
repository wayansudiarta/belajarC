/*
	multiply_mat.c
	Program untuk menghitung hasil perkalian produk antara matrix A dan matrix B.
	
	Source = http://www.sanfoundry.com/c-programming-examples-matrix/.
	
	Untuk mengkompilasi kode ini menggunakan perintah:
	gcc multiply_mat.c -o multiply_mat
	
	dan untuk menjalankan program ini menggunakan cara:
	./multiply.exe
*/

#include <stdio.h>
 
int main()
{
	int m, n, p, q, c, d, k, sum = 0;
	int pertama[10][10], kedua[10][10], kali[10][10];
 
 	// (1) Memasukan nilai kedua matrix
	printf("Masukn jumlah baris dan kolom matrix A...\n");
	scanf("%d%d", &m, &n);
	printf("Masukan nilai untuk matrix %dx%d A.\n",m,n);

	for (  c = 0 ; c < m ; c++ ){

		for ( d = 0 ; d < n ; d++ ){
			scanf("%d", &pertama[c][d]);
		}
	}
 
	printf("Masukan jumlah baris dan kolom matrix B...\n");
	scanf("%d%d", &p, &q);
 
	if ( n != p ){
		printf("Maaf, kedua matrix tidak dapat dikalikan.\n");
		return 0;
	}
	
	else{
    printf("Masukan nilai untuk matrix %dx%d B\n",p,q);
    
	}
	
	for ( c = 0 ; c < p ; c++ ){
	
		for ( d = 0 ; d < q ; d++ ){
        	scanf("%d", &kedua[c][d]);
    	}
	}
	
	// (2) Perhitungan perkalian kedua matrix
	for ( c = 0 ; c < m ; c++ ){
		
      for ( d = 0 ; d < q ; d++ ){
      	
        for ( k = 0 ; k < p ; k++ ){
          sum = sum + pertama[c][k]*kedua[k][d];
        }
 
        kali[c][d] = sum;
        sum = 0;
      }
    }
 
 	// (3) Keluaran atau hasil dari perkalian matrix A dan B
    printf("\n\nHasil perkalian kedua matrix ...:-\n");
 
	for ( c = 0 ; c < m ; c++ ){
		
		printf("\n");
		
		for ( d = 0 ; d < q ; d++ ){
			
        	
			printf("%d\t", kali[c][d]);
      
    }
  }
 
  return 0;
}
