/*
   regresi.c
   Merupakan suatu program untuk menentukan nilai slope dan intercept dari dua buah data.
   
   Untuk mengkompilasi kode ini menggunakan perintah:
   gcc regresi.c -o regresi
   
   dan untuk menjalankan program ini menggunakan:
   ./regresi.exe
*/

#include <stdio.h>
#include <math.h>

int main()
{
	int Size;
	printf("Masukan Banyak Element : ");
    scanf("%d",&Size);
    
    // (1) Pendeklarasian nilai masukan baik banyak data dan ilai dari data
    //     yaitu data X dan Y
    double sum_y=0,sum_xy=0,sum_x=0,sum_xx=0,sum_x2=0,slope=0,intercept=0,reg;
    int i;
    float xx[Size],yy[Size],nr=0,dr=0;
    float x[Size],y[Size];
    int n = Size;
    
    printf("\nMasukan elemen X sebanyak %d\n",Size);
    for (i = 0; i < Size; i++){
    	scanf("%f",&x[i]);
	}
	printf("\nMasukan elemen Y sebanyak %d\n",Size);
    for (i = 0; i < Size; i++){
    	scanf("%f",&y[i]);
	}
   
    printf ("\nX = ");
	for(i = 0; i < n; i++){
		
		printf("%.2f ",x[i]);
	
   }
   
    printf ("\nY = ");
	for(i = 0; i < n; i++){
		
		printf("%.2f ",y[i]);
	
   }
   
   // (2) Proses perhitungan nilai slope dan intercept
    for(i=0;i<n;i++){
    	xx[i]=x[i]*x[i];
    	yy[i]=y[i]*y[i];
    }
    
    for(i=0;i<n;i++){
    	sum_x+=x[i];
   	 	sum_y+=y[i];
    	sum_xx+= xx[i];
    	sum_xy+= x[i]*y[i];
    }
    
    nr=(n*sum_xy)-(sum_x*sum_y);
    sum_x2=sum_x*sum_x;
    dr=(n*sum_xx)-sum_x2;
    
    slope = ((sum_y*sum_xx)-(sum_x*sum_xy))/dr;
    
    intercept = nr/dr;
    
	
    // menampilkan hasil keluaran slope dan intercept
    printf("\n\nNilai Slope : %.2f\n\nNilai Intercept : %.2f",slope,intercept);
    
    return 0;
}
