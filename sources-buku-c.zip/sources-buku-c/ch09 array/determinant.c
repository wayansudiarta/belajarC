/*
  determinant.c
  Merupakan program untuk menentukan determinan suatu matrix
  
  Untuk kompilasi kode menggunakan perintah:
  gcc determinant.c -o determinant
  
  Untuk menjalankan program ini dengan cara:
  ./determinant.exe
*/
#include<stdio.h>
 
int main(){
 
	int a[3][3], i, j;
 
	long determinant;
  
  	// (1) Masukan data untuk matrix
	printf("Masukan element matrix 3x3: \n");
	for(i = 0 ;i < 3;i++){
	
		for(j = 0;j < 3;j++){
		
			scanf("%d", &a[i][j]);
		}
	}
 
	printf("\nMatrix yang dimasukan...\n");
	for(i = 0;i < 3; i++){
		printf("\n");
		
		for(j = 0;j < 3; j++){
		
           printf("%d\t", a[i][j]);
    	}
	}
 	
 	// (2) Menentukan determinan matrix
	determinant = a[0][0]*((a[1][1]*a[2][2])-(a[2][1]*a[1][2]))-a[0][1]*(a[1][0]*a[2][2]-a[2][0]*a[1][2])+a[0][2]*(a[1][0]*a[2][1]-a[2][0]*a[1][1]);
 
	printf("\n\nDeterminant dari matrix 3x3: %ld", determinant);
 
   return 0;
}
