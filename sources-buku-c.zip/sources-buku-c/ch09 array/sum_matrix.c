/*
   sum_matrix.c
   Program bahasa C untuk Penjumlahan Matrix 3x3.
   Source = http://www.sanfoundry.com/c-programming-examples-matrix.
   
   Untuk mengkompilasi kode ini menggunakan perintah:
   gcc sum_matrix.c -o sum_matrix
   
   dan untuk menjalankan program ini dengan cara:
   ./sum_matrix.exe
 */
#include <stdio.h>
int main()
{
	// (1) Inisialisasi Matrix dimensi 2
	int array1[3][3] = {{1,1,1},{2,2,2},{3,3,3}};
	int array2[3][3] = {{1,2,3},{1,2,3},{1,2,3}};
	int arraysum[10][10];
    int i, j, m, n, option;
 
 
    printf("MATRIX array1 ... \n");
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 3; j++)
        {
            printf("%3d", array1[i][j]);
        }
        printf("\n");
    }

    printf("MATRIX array2 ... \n");
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 3; j++)
        {
            printf("%3d", array2[i][j]);
        }
        printf("\n");
    }

		//  (2) Proses penjumlahan matrix 1 dan matrix 2
        for (i = 0; i < 3; i++)
        {
            for (j = 0; j < 3; j++)
            {
                arraysum[i][j] = array1[i][j] + array2[i][j];
            }
        }
        
        // (3) Hasil penjumlahan matrix 1 dan 2
        printf("Hasil Penjumlahan Kedua Matrix ... \n");
        for (i = 0; i < 3; i++)
        {
            for (j = 0; j < 3; j++)
            {
                printf("%3d", arraysum[i][j]) ;
            }
            printf("\n");
        }
 
 		return 0;
}

