/*
 * array.c
 * Program C untuk pengenalan cara deklarasi inisialisasi, dan mengakses sebuah array
 
   Untuk kompilasi kode menggunakan perintah:
   gcc array.c -o array
   
   dan untuk menjalankan programnya dengan cara:
   ./array.exe
*/

#include<stdio.h>

int main(){
	
	// (1) Proses deklarasi dan inisialisasi array g
	int g[10]={0,1,2,3,4,5,6,7,8,9};
	
	int i;
	
	// (2) Untuk mengambil atau mengakses nilai array g
	for(i=0;i<10;i++){
		printf("g[%d]= %d \n",i,g[i]);
	}
	
	return 0;
}
