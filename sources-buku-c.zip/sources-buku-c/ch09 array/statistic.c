/*
 * Statistic.c
   Program untuk menentukan mean,median,modus, dan standar deviasi suatu data
   Source = http://www.sanfoundry.com/c-programming-examples.
   
   Untuk mengkompilasi kode ini menggunakan perintah:
   gcc statistic.c -o statistic
   
   dan untuk menjalankan program ini menggunakan cara:
   ./statistic.exe
*/
#include <stdio.h>
#include <math.h>

#define MAX 10
int main(){
	
	
	float data[MAX];
	int i,N;
	float tot = 0, mean = 0, variance, std_deviation;
	float tengah=0;
	int j,z, tmp, maxCount, modusval;
	int tally[N];
	
	// (1) Memasukan nilai pada ang ingin di olah
	printf("Masukan Jumlah Data max 10 ... \n");
    scanf("%d", &N);
    
    printf("\nMasukan nilai sebanyak %d \n", N);
    
    for (i = 0; i <N; i++){
    	
        scanf("%f", &data[i]);
    }
    
    printf("\nNilai yang anda masukan adalah ...\n");
    for (i = 0; i < N; i++){
    	
    	printf("%.2f ",data[i]);
	}
	
	// (2) Menghitung nilai rata-rata atau mean
	for(i=0; i<N; i++){
		tot = tot+data[i];
	}
	
	mean = tot/N;
	printf("\n\nNilai rata-rata : %.1f\n",mean);
			
    // (3) Menghitung nilai tengah atau median 
	if(N%2 == 0){
		
		int temp=(N/2)-1;
		
		for(i=0;i<N;i++){
			
			if(temp==i || (temp+1)==i){
				tengah=tengah+data[i];
		   }
		}
	
		tengah=tengah/2;
		
		printf("Nilai Median/Nilai Tengah : %.1f",tengah);
	}
		
	else {
		int temp=(N/2);
		
		for(i=0;i<N;i++){
			
			if(temp==i){
				int tengah=data[i];
		        printf("Nilai Median/Nilai Tengah: %d",tengah);
		   }
		}
	}
		
		
	// (4) Menghitung nilai terbanyak atau modus
	for(i=0;i<N;i++){
		
		for(j=0;j<N-i;j++){
			
		    if(data[j]>data[j+1]){
		        tmp=data[j];
		        data[j]=data[j+1];
		        data[j+1]=tmp;
		    }
		}
	}
		         
	for (i = 0; i < N; i++) {
		
		for(z=i+1;z<N;z++){
		            
		    if(data[i]==data[z]){
		        tally[i]++;
		    }
		}
	}
		    
		    maxCount = 0;
		    modusval = 0;
		    
	for (i = 1; i <= N; i++){
		if (tally[i] > maxCount) {
		    maxCount = tally[i];
		    modusval = data[i];
    	}
	}
		    
	printf("\nNilai Modus : %d\n", modusval);
	
	// (5) Menghitung nilai standar deviasi
	for (i = 0; i < N; i++){
        tot = tot + pow((data[i] - mean), 2);
    }
    
    variance = tot / (float)N-1; 
    
    std_deviation = sqrt(variance);
    
    printf("Nilai Standar Deviasi : %.2f", std_deviation);
    
	return 0;
}
