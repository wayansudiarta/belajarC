/* 
  ascii.c
  Merupakan kode program untuk menampilkan nilai ASCII dari character baik huruf maupun angka
  
  Untuk kompilasi kode program ini menggunakan perintah :
  gcc ascii.c -o ascii
  
  dan untuk menjaakan kode program ini dengan cara :
  ./ascii.exe
*/
#include <stdio.h>
 
int main()
{
  char ch1,ch2;
  
  // (1) Memasukan huruf atau angka yang ingin diketahui nilai ascii-nya
  printf("Masukan dua buah huruf atau angka \n");
  scanf(" %c\n",&ch1);
  scanf(" %c",&ch2);
  
  // (2) Keluaran nilai ascii berbentuk int(%d) pada suatu huruf atau angka berbentuk char
  printf("\nNilai ASCII dari huruf atau angka %c = %d",ch1,ch1);
  printf("\nNilai ASCII dari huruf atau angka %c = %d",ch2,ch2);
  
  return 0;
}
