/*
	dencrypt.c
	Merupakan kode program untuk mendekripsikan suatu pesan.
	 Source = http://www.sanfoundry.com/c-programming-examples.
	
	Untuk kolpilasi kode program ini mengunakan perintah:
	gcc dencrypt.c -o dencrypt
	
	dan untuk menjalakanya menggunakan cara :
	./dencrypt.exe
*/

#include <stdio.h>
#include <string.h>

int main()
{
    char password[20] ;
    int i;
    char key[10];
    
    // (1) Memasukan pesan yg ingin di deskripsi
    printf("Masukan pesan:\n");
    scanf("%s",password);
    printf("Masukan satu kata kunci:\n");
    scanf("%s",key);
    
    // (2) Proses dekripsi pesan
    for (i = 0;i < strlen(password); i++){
    	password[i] = password[i] + key[i];
	}
	
	// (3) Menampilkan hasil dekripsi pesan
	printf ("Mendekripsikan pesan .........\n\n%s",password);
    
    
    return 0;
}
