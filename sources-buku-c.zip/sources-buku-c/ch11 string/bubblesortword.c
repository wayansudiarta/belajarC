/*
	bubblesortword.c
	Merupakan program sortir character huruf kapital kemudian diurutkan berdasarkan alfabet.
	
	 Source = http://www.sanfoundry.com/c-programming-examples.
	
	Untuk kompilasi kode program ini menggunakan perintah:
	gcc bubblesortword.c -o bubblesortword
	
	dan untuk menjalankanya meggunakan cara :
	./bubblesortword.exe
*/
#include<stdio.h>
#include<string.h>
 
int main() 
{
   // (1) Proses deklarasi dan inisialisasi huruf kapital yang ingin diurutkan
   char s[5][20], t[20];
   int i, j;
   
   printf("Masukan 5 buah character huruf kapital: \n");
   for (i = 0; i < 5; i++)
   
      scanf("%s", s[i]);
      
 	// (2) Proses pengurutan huruf kapital yang dimasukan berdasarkan alfabet
   for (i = 1; i < 5; i++) {
      
	  for (j = 1; j < 5; j++) {
         
		 if (strcmp(s[j - 1], s[j]) > 0) {
       
	        strcpy(t, s[j - 1]);
       
	        strcpy(s[j - 1], s[j]);
       
	        strcpy(s[j], t);
         }
      }
   }
 
	// (3) Hasil pengurutan sesuai alfabet.
   printf("\nSetelah diurutkan berdasarkan alfabet menjadi...");
   
   for (i = 0; i < 5; i++){
   
      printf("\n%s", s[i]);
 
   
}
}
