/*
	String.c
	Merupakan kode program dasar pengenalan string tentang cara deklarasi, inisialisasi, dan mengakses suatu string
	
	untuk mengkompilasi kode program ini menggunakan perintah :
	gcc String.c -o String
	
	dan untuk kompilasi program ini dengan cara :
	./String.exe
*/

#include <stdio.h>

int main()
{
	
	// (1) Deklarasi dan inisialisasi string dengan 2 cara.
	char str1[6] = {'H','E','L','L','O','\0'};
	char str2[] = "HELLO"; 
	
	// (2) Mengakses string 
	printf("Pesan1 : %s\n",str1);
	printf("Pesan2 : %s",str2);
	
	return 0;
	
}
