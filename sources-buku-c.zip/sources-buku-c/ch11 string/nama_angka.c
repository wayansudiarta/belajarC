/*
	nama_angka.c
	Merupakan program untuk merubah nama anda dalam huruf a-z menjadi angka 1-26.
	kemudian menjumlahkanya.
	
	 Source = http://www.sanfoundry.com/c-programming-examples.
	
	Untuk kompilasi kode program ini menggunakan perintah :
	gcc nama_angka.c -o nama_angka
	
	dan untuk menjalaknya menggunakan :
	./nama_angka.exe
*/

#include<stdio.h>

int main(){
	
	char nama[10];
	int i,len = 0;
	
	// (1)Masukan nama dalam huruf kecil yang akan diubah ke angka 1-26.
	printf("Masukan nama anda :\n");
	gets(nama);
	 
	// (2) Proses perubahan huruf menjadi angka dan menjumlahkanya
	//     yaitu menggunakan nilai ASCII pada huruf tersebut a = 97
	for (i = 0; i < strlen(nama); i++){
		
		nama[i] = nama[i]-96;
		
		len = len +nama[i];	
	}
	
	// (3) Menampilkan hasil penjumlahan nama anda.
	printf("\nJumlah nama anda adalah : %d",len);
	
	
	return 0;
}
