/*
	encrypt.c
	Merupakan kode program untuk mengekripsikan suatu pesan.
	 Source = http://www.sanfoundry.com/c-programming-examples.
	
	Untuk kolpilasi kode program ini mengunakan perintah:
	gcc encrypt.c -o encrypt
	
	dan untuk menjalakanya menggunakan cara :
	./encrypt.exe
*/

#include <stdio.h>
#include <string.h>

int main()
{
    char password[20] ;
    int i;
    char key[10];
    
    // (1) Memasukan pesan yang akan di-enkripsi.
    printf("Masukan pesan:\n");
    scanf("%s",password);
     
    printf("Masukan satu kata kunci:\n");
    scanf("%s",key);
    
    // (2) Proses enkripsi pesan
    for (i = 0; i < strlen(password); i++){
    	password[i] = password[i] - key[i];
	}
	
	// (3) Menampilkan hasil enkripsi
    printf("Mengekripsikan pesan ..........\n\n%s",password);
    
    
    
    return 0;
}
