/*
	stringh.c
	Marupakan kode program string menggunakan library <string.h> untuk mempermudah melakukan berbagai fungsi.
	
	Untuk kompilasi kode program ini menggunakan perintah :
	gcc stringh.c -o stringh
	
	dan menjalakan kode program ini menggunakan :
	./stringh.exe
*/
#include<stdio.h>
#include<string.h>

int main(){
	
	// (1)Deklarasi string 
	char a[10] = "problem";
	char b[10] = "solving";
	char c[10];
	int perbandingan;
	int panjang;
	
	printf("String a adalah : \"%s\"\n",a);
	printf("\nString b adalah : \"%s\"\n",b);
	
	// (2) fungsi strcpy untuk mengkopi nilai dari string b ke string c
	strcpy(c,b);

	printf("\nString c menjadi \"%s\"\n",c);
	
	// (3) fungsi strcmp untuk membandingkan nilai antara string a dan b,
	//     jika string a == b nilainya 0,
	//     jika string a <  b nilainya -1
	//     jika string a <  b nilainya 1
	perbandingan = strcmp(a, b);
	
	printf("\nNilai perbandingan %s dan %s adalah %d\n",a,b,perbandingan);
	
	if (perbandingan == 0){
		printf("\nNilai string a sama dengan b\n");
	}
	
	else if (perbandingan > 0){
		printf("\nNilai string a > b\n");
	}
	
	else{
		printf("\nNilai string a < b\n");
	}
	
	// (4) Memasukan string b kedalam string a atau kedua string digabungkan
	strcat(a,b);
	
	printf("\nGabungan string a dan b adalah |%s|\n",a);
	
	// (5) Mencari panjang string dari gabungan string a dan b.
	panjang = strlen(a);
	
	printf("\nPanjang string %s adalah: %d",a,panjang);
	
	
	return 0;
}
