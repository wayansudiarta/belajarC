/* helloGLUT.c
 
	Kode ini merupakan modifikasi dari sourcecode:
	https://github.com/TransmissionZero/Hello-GLUT
	
	HelloGLUT.c merupakan contoh sederhana OpenGL dengan FreeGLUT
	Program in menampilkan kotak merah, dan keluar ketika tombol 
	[x] ditekan.
	
	Kompilasi:
	gcc -o helloGLUT.exe helloGLUT.c -lfreeglut -lopengl32 -Wl,--subsystem,windows

 */

#include <stdlib.h>
#include <GL/glut.h>


/* Callback function declarations */
void keyboard(unsigned char key, int x, int y);
void display(void);



/* Main method */
int main(int argc, char** argv)
{
  glutInit(&argc, argv);

  /* Create a single window with a keyboard and display callback */
  glutCreateWindow("GLUT Test");
  glutKeyboardFunc(&keyboard);
  glutDisplayFunc(&display);

  /* Run the GLUT event loop */
  glutMainLoop();

  return EXIT_SUCCESS;
}


/* Keyboard callback function */
void keyboard(unsigned char key, int x, int y)
{
  switch (key)
  {
    /* Exit on escape key press */
    case '\x1B':
    {
      exit(EXIT_SUCCESS);
      break;
    }
  }
}

/* Display callback function */
void display()
{
  glClear(GL_COLOR_BUFFER_BIT);

  /* Display a red square */
  glColor3f(1.0f, 0.0f, 0.0f);

  glBegin(GL_POLYGON);
    glVertex2f(-0.5f, -0.5f);
    glVertex2f( 0.5f, -0.5f);
    glVertex2f( 0.5f,  0.5f);
    glVertex2f(-0.5f,  0.5f);
  glEnd();

  glFlush();
}
