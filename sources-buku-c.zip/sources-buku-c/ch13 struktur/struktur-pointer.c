/* struktur-pointer.c
 * Contoh Struktur data Mahasiswa
 * gcc struktur-data.c -o struktur-data.exe
 * Penggunaan Pointer
 */

#include <stdio.h>
#include <string.h>

// definisi struktur mahasiswa
struct mahasiswa {
	char *nama;
	char *nim;
	int umur;
	float tinggi;
	float berat;
};

int main()
{
	struct mahasiswa m;
	struct mahasiswa *p;

	// pointer ke alamat m
	p = &m;

	// cara pertama mengakses struktur   
	p->nama = "Albert Einstein";
	p->nim = "B00131582";
	p->umur = 25;
	p->tinggi = 170.0;
	p->berat = 62.0;

	// cara kedua mengakses struktur   
	(*p).nama = "Albert Einstein";
	(*p).nim = "B00131582";
	(*p).umur = 25;
	(*p).tinggi = 170.0;
	(*p).berat = 62.0;
	 
	// print data
	printf(" Nama = %s \n", m.nama);
	printf(" NIM  = %s \n", m.nim);
	printf(" Umur = %d \n", m.umur);
	printf(" Tinggi = %f \n", m.tinggi);
	printf(" Berat = %f \n", m.berat);
   
	return 0;
}
