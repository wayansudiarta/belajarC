/* struktur-data.c
 * Contoh Struktur data Mahasiswa
 * gcc struktur-data.c -o struktur-data.exe
 *
 */

#include <stdio.h>
#include <string.h>

// definisi struktur mahasiswa
struct mahasiswa {
   char *nama;
   char *nim;
   int umur;
   float tinggi;
   float berat;
};

int main()
{
   struct mahasiswa m;

   // input data   
   m.nama = "Albert Einstein";
   m.nim = "B00131582";
   m.umur = 25;
   m.tinggi = 170.0;
   m.berat = 62.0;
   
   // print data
   printf(" Nama = %s \n", m.nama);
   printf(" NIM  = %s \n", m.nim);
   printf(" Umur = %d \n", m.umur);
   printf(" Tinggi = %f \n", m.tinggi);
   printf(" Berat = %f \n", m.berat);
   
   return 0;
}
