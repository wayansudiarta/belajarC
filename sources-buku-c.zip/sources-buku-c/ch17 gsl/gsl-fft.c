/* gsl-fft.c
 * mengikuti contoh pada situs GSL
 * kompilasi:	
 *  gcc -Wall -I/usr/local/include -c gsl-fft.c
 *  gcc -L/usr/local/lib gsl-fft.o -lgsl -lgslcblas -lm -o gsl-fft.exe
 */

#include <stdio.h>
#include <math.h>
#include <gsl/gsl_errno.h>
#include <gsl/gsl_fft_complex.h>

#define N 128   //harus N = 2^m

int main (void)
{
  int i, j;
  double dataIm[N];
  double dataRe[N];
	double data[2*N];
  double fftIm[N];
  double fftRe[N];
  double ifftIm[N];
  double ifftRe[N];

  // buat data	
  for (i = 0; i < N; i++){
    if(fabs(i-N/2) < 20){
			dataRe[i] = 1.0;
		}else{
			dataRe[i] = 0.0;
		}
    dataIm[i] = 0.0;
  }

	//array untuk bagian real dan imaginary ditempatkan pada array
	//dengan posisi bergiliran
  j = 0;
	for (i = 0; i < N; i++){
    data[j] = dataRe[i];
		j++;
    data[j] = dataIm[i];
		j++;
  }
	
	// menggunakan FFT Radix2
  gsl_fft_complex_radix2_forward(data, 1, N);

	// Ambil hasil FFT
  j = 0;
	for (i = 0; i < N; i++){
    fftRe[i] = data[j];
		j++;
    fftIm[i] = data[j];
		j++;
  }

	// menggunakan FFT Radix2
  gsl_fft_complex_radix2_inverse(data, 1, N);

	// Ambil hasil FFT
  j = 0;
	for (i = 0; i < N; i++){
    ifftRe[i] = data[j];
		j++;
    ifftIm[i] = data[j];
		j++;
  }
	
	// print input dan output, fft = FFT(data), ifft = IFFT(fft)
	// catatan ifft = data
	for (i = 0; i < N; i++){
		printf("%lf  %lf  %lf  %lf %lf  %lf\n", dataRe[i], dataIm[i], fftRe[i], fftIm[i], ifftRe[i], ifftIm[i]);
	}
	
  return 0;
}
