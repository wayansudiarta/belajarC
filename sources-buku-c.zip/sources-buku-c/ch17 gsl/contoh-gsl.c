/* contoh-gsl.c
 * menghitung fungsi Bessel J0(x)
 * diambil dari: contoh pada situs Pustaka GSL	
 * kompilasi:
 *  gcc -Wall -I/usr/local/include -c contoh-gsl.c
 *  gcc -L/usr/local/lib contoh-gsl.o -lgsl -lgslcblas -lm -o contoh-gsl.exe
 */

#include <stdio.h>
#include <gsl/gsl_sf_bessel.h>

int main (void)
{ 
   double x,y;
   		
   x = 5.0;
   y = gsl_sf_bessel_J0 (x);
   printf("J0(%lf) = %lf \n", x, y);
   
   return 0;
}
