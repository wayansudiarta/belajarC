/* gsl-eigen.c
 * Mendapatkan nilai eigen dan vektor eigen sebuah matriks riil
 * Mengikuti contoh di situs GSL
 * kompilasi:
 *  gcc -Wall -I/usr/local/include -c contoh-gsl.c
 *  gcc -L/usr/local/lib contoh-gsl.o -lgsl -lgslcblas -lm -o contoh-gsl.exe
 */ 

#include <stdio.h>
#include <gsl/gsl_math.h>
#include <gsl/gsl_eigen.h>

#define N 3

int main (void)
{
	int i;
	// input matriks
  double data[] = { 2, 1, 0,
										1, 2, 1,
                    0, 1, 2};
  gsl_matrix_view m = gsl_matrix_view_array (data, N, N);

	double eigenVal_i;
  gsl_vector_view eigenVec_i;
  gsl_vector *eigenVal = gsl_vector_alloc (N);
  gsl_matrix *eigenVec = gsl_matrix_alloc (N, N);
  gsl_eigen_symmv_workspace *w = gsl_eigen_symmv_alloc (N);
  
	// solve and sort results
  gsl_eigen_symmv (&m.matrix, eigenVal, eigenVec, w);
  gsl_eigen_symmv_sort (eigenVal, eigenVec,GSL_EIGEN_SORT_ABS_ASC);
  
	// output
  for (i = 0; i < N; i++){
    eigenVal_i = gsl_vector_get (eigenVal, i);
    eigenVec_i = gsl_matrix_column (eigenVec, i);
    printf ("eigenvalue = %g\n", eigenVal_i);
    printf ("eigenvector = \n");
    gsl_vector_fprintf (stdout, &eigenVec_i.vector, "%g");
  }

	// free memory
  gsl_eigen_symmv_free (w);
  gsl_vector_free (eigenVal);
  gsl_matrix_free (eigenVec);

  return 0;
}
