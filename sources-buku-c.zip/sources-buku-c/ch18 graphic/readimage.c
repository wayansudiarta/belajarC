/* readimage.c 
 * Membuat gambar tiga lingkaran dengan pustaka
 * graphics Borland Graphics Interface (BGI) untuk Windows
 * Unduh di http://winbgim.codecutter.org/
 * http://www.cs.colorado.edu/~main/cs1300/doc/bgi/bgi.html
 * Kompilasi:
 * g++ readimage.c -o readimage.exe -mwindows -lbgi -lgdi32 
 * -lcomdlg32 -luuid -loleaut32 -lole32  
 */ 

#include "graphics.h"
#include <stdlib.h>
#include <stdio.h>

int main(void)
{
	// variabel dan initialisasi autodetection dengan "DETECT" 
	int gdriver = DETECT, gmode, errorcode;

	int midx, midy;		// posisi tengah gambar dan jari-jari
	int radius;				// jari-jari linkaran
	
	initgraph(&gdriver, &gmode, "");	// initialisasi graphics 
	errorcode = graphresult(); 				// Baca hasil inisialisasi
	if (errorcode != grOk) {					//
		printf("Graphics error: %s\n", grapherrormsg(errorcode));
		exit(1);	// keluar program
	}
 
  readimagefile("einstein.jpg", 0,0,500,500);
	
	getch();			// tunggu input dari keyboard sebelum
	closegraph(); // tutup graphics

	return 0;
}

