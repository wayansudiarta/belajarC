/* mandelbrot.c 
	Program membuat fraktal Mandelbrot
	menggunakan fungsi initwindow() dan putpixel
	
	Kompilasi:
	g++ mandelbrot.c -o mandelbrot.exe -mwindows -lbgi -lgdi32 -lcomdlg32 -luuid -loleaut32 -lole32
 */ 

#include <graphics.h>
#include <stdlib.h>
#include <stdio.h>
#include <conio.h>

int main()
{
	int i, j, color, maxx, maxy, maxcolor;
	int n, nmax;
	long double x, y, dx, r2, x0, y0;
	long double xt, yt, cx, cy;
  
	/* initialize graphics */
	initwindow(600, 400, "Fraktal Mandelbrot");

	maxcolor = getmaxcolor();
	nmax = 13*maxcolor;
	r2 = 2.5*2.5;

	x0 = -1.82;
	y0 = 0.04;
	dx = 0.1/500;

	for(i=0; i<600; i++){
		for(j=0; j<400; j++){
			cx = x0 + i*dx;
			cy = y0 - j*dx;
			x = 0; y =0; 
			for( n = 0; n <= nmax; n++){
				// z_n+1 = z_n^2 + c
				xt = x*x - y*y + cx;
				yt = 2*x*y     + cy;
					
				x = xt;
				y = yt;
				if(x*x + y*y > r2){
					break;
				}
			}
			color = n%maxcolor - 1;
			putpixel(i, j, color);
		}
	}

	// wait
	getch();

	/* clean up */
	closegraph();

	return 0;
}
