/* simple-motion.c
	g++ simple-motion.c -o simple-motion.exe -mwindows -lbgi -lgdi32 -lcomdlg32 -luuid -loleaut32 -lole32
*/

#include<stdlib.h>
#include <graphics.h>

#define NX 400
#define NY 400

int main( )
{
	int x = 200, y = 200, dx, dy;
	int x2, y2;
	int n = 0;
	
	dx = 10;
	dy = rand()%10 - 5;
	
	initwindow(NX, NY, "Bola");
    
  while (!kbhit( ))
  {
		x2 = x;
		y2 = y;
		x += dx;
		y += dy;
		if(x > NX || x < 0){ 
			dx *= -1;
			n++;
		}
		
		if(y > NY || y < 0){ 
			dy *= -1;
			n++;
		}
		
		//setcolor(BLACK);
		//circle(x2, y2, 20);
		
		setcolor(n%15);
		circle(x, y, 20);

		delay(100);
  }
	
  return 0;
}
