/* grafik-regresi.c 
 * Membuat grafik fungsi dengan pustaka KoolPLot dan
 * graphics Borland Graphics Interface (BGI) untuk Windows
 * Unduh di http://winbgim.codecutter.org/
 * http://www.cs.colorado.edu/~main/cs1300/doc/bgi/bgi.html
 * http://koolplot.codecutter.org/

 Kompilasi:
   g++ grafik-regresi.c -o grafik-regresi.exe -mwindows -lkoolplot
  -lbgi -lgdi32 -lcomdlg32 -luuid -loleaut32 -lole32
 atau make grafik-regresi 
 
 Run:
 ./grafik-regresi.exe regresidata.dat 5

 */ 
#include <stdio.h>
#include <string.h>

#include "koolplot.h"

int main(int argc, char *argv[])
{
	// Bagian (1): Deklarasi variabel yang dibutuhkan
	FILE *infile;			// pointer untuk file
	Plotdata x, y;		// untuk KoolPlot
	long int i, n;		// variabel indeks dan nilai max indeks
	double *datax;		// menampung data x dan y
	double *datay;
	
	// variabel untuk menghitung regresi, sum x, sum x^2 dll
	// regresi linier y = m x + b
  double sx = 0.0, sx2 = 0.0, sxy = 0.0, sy = 0.0, sy2 = 0.0;  
	double temp;
	double m, b, dx;

	double xx, xmin, xmax;
	
	// Bagian (2): Input Data
	n = atol(argv[2]);  //jumlah data dari command prompt
	// alokasi memori
	datax = (double *) malloc((size_t) (n*sizeof(double)));
	datay = (double *) malloc((size_t) (n*sizeof(double)));
  
	//scan data file
	infile = fopen(argv[1],"r"); 
	for(i = 0; i < n; i++){
			fscanf(infile, "%lf  %lf", &datax[i], &datay[i]);
	}	
	
	// Bagian (3): Olah Data untuk memperoleh nilai m dan b
	// Hitung parameter untuk regresi linier
  for (i = 0; i < n; i++){ 
		sx  += datax[i];       
		sx2 += datax[i]*datax[i];  
		sxy += datax[i]*datay[i];
		sy  += datay[i];      
		sy2 += datay[i]*datay[i]; 
	} 

	temp = n*sx2 - sx*sx;
  if (fabs(temp)<1.0E-10) {
		m = 0;
		b = 0;
	}else{
		m = (n*sxy  -  sx*sy)/temp;
		b = (sy*sx2  -  sx*sxy)/temp;
	}

	// Bagian (4): Buat Grafik data dan garis regresi linier
	// tambahkan titik2 garis regresi
	// asumsi data sudah diurutkan dari terkecil
	xmin = floor(datax[0]) -1;
	xmax = ceil(datax[n-1]) + 1;
	dx = (xmax - xmin)/100.0;
  for(i = 0; i <= 100; i++){
		xx = xmin + i*dx;
		temp = m*xx + b;
		//Gunakan  << atau fungsi point(x,y,datax, datay)
		//x << xx;
		//y << temp;
		point(x, y, xx , temp); 
  }             
  
	//tambahkan data pada grafik
  for(i = 0; i < n; i++){
		addMark(x, y, datax[i], datay[i]); 
  }             
  plot (x, y, "Regresi Linier");

	// Bagian (5): Memori dikembalikan
	free(datax);
	free(datay);
	
	return 0;
}    