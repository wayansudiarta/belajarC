/* potensial-hue.c */ 

#include <graphics.h>
#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <dos.h>
#include <math.h>

#define PIXEL_COUNT 5000
#define DELAY_TIME  100  /* in milliseconds */


/* Fungsi ini dimodifikasi dari
http://stackoverflow.com/questions/8208905/hsv-0-255-to-rgb-0-255
*/
struct RGB{ int r, g, b;};
typedef struct RGB warna;

warna hsvToRgb(float h, float s, float v){
    int r, g, b;
		warna c;

		h/=60;
    int i = floor(h);
    float f = h - i;
    float p = v * (1 - s);
    float q = v * (1 - f * s);
    float t = v * (1 - (1 - f) * s);

    switch(i){
        case 0: r = v, g = t, b = p; break;
        case 1: r = q, g = v, b = p; break;
        case 2: r = p, g = v, b = t; break;
        case 3: r = p, g = q, b = v; break;
        case 4: r = t, g = p, b = v; break;
        case 5: r = v, g = p, b = q; break;
    }

    c.r = (int)r * 255;
		c.g = (int)g * 255;
		c.b = (int)b * 255;
		//printf("%d  %d  %d\n",c.r, c.g, c.b);
		
		return c;
}

int main()
{
   /* request autodetection */
   int gdriver = DETECT, gmode, errorcode;
   int i, j, color, maxx, maxy, maxcolor;
	warna c;
	 
   float x, y, dx;
   float x1, y1, r1;
   float x2, y2, r2;
   float v, dv, v0;
   float q1, q2;
    
   /* initialize graphics and local variables */
   initgraph(&gdriver, &gmode, "");
   /* read result of initialization */
   errorcode = graphresult();
   if (errorcode != grOk) {  /* an error occurred */
      printf("Graphics error: %s\n", grapherrormsg(errorcode));
      printf("Press any key to halt:");
      getch();
      exit(1);               /* terminate with an error code */
   }
   maxx = getmaxx() + 1;
   maxy = getmaxy() + 1;
   maxcolor = getmaxcolor() + 1;
   dx = 0.5;
   dv = 0.005/dx;
   x1 = (maxx/2 - 50)*dx;
   y1 = (maxy/2)*dx;
   x2 = (maxx/2 + 50)*dx;
   y2 = (maxy/2)*dx;
   v0 = 1/dx;
   q1 = 4.0;
   q2 = 1.0;
   for(i=0; i<maxx; i++){
      for(j=0; j<maxy; j++){
         x = i*dx;
         y = j*dx;
         r1 = sqrt((x-x1)*(x-x1) + (y-y1)*(y-y1));
         if(r1<dx) r1 = dx;
         r2 = sqrt((x-x2)*(x-x2) + (y-y2)*(y-y2));
         if(r2<dx) r2 = dx;
         v = q1/r1 + q2/r2;
         if(v>0.4){v=0.4;}
				 color = (int)40*v;
         putpixel(i, j, color);
      }
   }
   setfillstyle(SOLID_FILL,WHITE);
   setcolor(0);
   fillellipse(maxx/2 - 50,maxy/2,15,15);
   fillellipse(maxx/2 + 50,maxy/2,15,15);
   setbkcolor(WHITE);
   outtextxy(maxx/2 - 50 -10,maxy/2-10,"q1");
   outtextxy(maxx/2 + 50 -10,maxy/2-10,"q2");
   
   /* clean up */
   getch();

   closegraph();
   return 0;
}

