/* simple-graph.c
	Program Sederhana menggunakan inisialisasi
	initwindow() dan menentukan posisi mouse dengan
	getmouseclick()
	
	Kompilasi:
	g++ simple-graph.c -o simple-graph.exe -mwindows -lbgi -lgdi32 -lcomdlg32 -luuid -loleaut32 -lole32
*/

#include <graphics.h>

int main( )
{
	int x, y;
	int n = 0;
	
	initwindow(500, 500, "Mouse Input");
	setfillstyle(SOLID_FILL, WHITE);
	bar(0,0,getmaxx(),getmaxy());		// Kotak untuk Background
	
	// perulangan sampai ada input dari keyboard
  while (!kbhit( ))
  {
		n++;

		// Mendapatkan posisi mouse
		//getmouseclick(WM_MOUSEMOVE, x, y);
		//getmouseclick(WM_LBUTTONDOWN, x, y);
		// 
		x = mousex(); y = mousey();
		// Mengganti warna 
		setcolor(n%15);
		
		// menggambar lingkaran
		circle(x, y, 40);

		// menunggu selama 200 ms
		delay(200);
  }
	
  return 0;
}
