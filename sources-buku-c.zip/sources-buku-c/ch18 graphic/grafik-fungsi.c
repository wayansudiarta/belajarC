/* grafik-fungsi.c 
 * Membuat grafik fungsi dengan pustaka KoolPLot dan
 * graphics Borland Graphics Interface (BGI) untuk Windows
 * Unduh di http://winbgim.codecutter.org/
 * http://www.cs.colorado.edu/~main/cs1300/doc/bgi/bgi.html
 * http://koolplot.codecutter.org/
 Kompilasi:
  g++ grafik-fungsi.c -o grafik-fungsi.exe -mwindows -lkoolplot
      -lbgi -lgdi32 -lcomdlg32 -luuid -loleaut32 -lole32  
  atau
		make grafik-fungsi
 Run:
	./grafik-fungsi.exe
 */ 

#include "koolplot.h"

int main()
{
	Plotdata x(0, 360.0), y = cos(x * M_PI / 180);
	plot(x, y);

	return 0;
}    