/* circle.c 
 * Membuat gambar tiga lingkaran dengan pustaka
 * graphics Borland Graphics Interface (BGI) untuk Windows
 * Unduh di http://winbgim.codecutter.org/
 * http://www.cs.colorado.edu/~main/cs1300/doc/bgi/bgi.html
 * Kompilasi:
 * g++ circle.c -o circle.exe -mwindows -lbgi -lgdi32 
 * -lcomdlg32 -luuid -loleaut32 -lole32  
 */ 

#include "graphics.h"
#include <stdlib.h>
#include <stdio.h>

int main(void)
{
	// variabel dan initialisasi autodetection dengan "DETECT" 
	int gdriver = DETECT, gmode, errorcode;

	int midx, midy;		// posisi tengah gambar dan jari-jari
	int radius;				// jari-jari linkaran
	
	initgraph(&gdriver, &gmode, "");	// initialisasi graphics 
	errorcode = graphresult(); 				// Baca hasil inisialisasi
	if (errorcode != grOk) {					//
		printf("Graphics error: %s\n", grapherrormsg(errorcode));
		exit(1);	// keluar program
	}
 
	midx = getmaxx() / 2;							// Posisi tengah
	midy = getmaxy() / 2;
	radius = 100;
	
	setfillstyle(SOLID_FILL, WHITE);
	bar(0,0,getmaxx(),getmaxy());		// Kotak untuk Background
	
	outtextxy(20, 20, "Program Grafik Pertama");

	setlinestyle(SOLID_LINE, 1, 3);
	setcolor(RED);									// pilih warna lingkaran 1
	circle(midx - 50, midy + 50, radius);// gambar lingkaran 1
	setcolor(GREEN);								// pilih warna lingkaran 2
	circle(midx, midy - 50, radius);// gambar lingkaran 2
	setcolor(BLUE);									// pilih warna lingkaran 2
	circle(midx + 50, midy + 50, radius);// gambar lingkaran 3

	getch();			// tunggu input dari keyboard sebelum
	closegraph(); // tutup graphics

	return 0;
}

