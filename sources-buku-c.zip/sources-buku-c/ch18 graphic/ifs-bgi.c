/* ifs-bgi.c
 * iterated funcktion systems untuk membuat fraktal
 * dengan pustaka Borland Graphics Interface (BGI) untuk Windows
 * Unduh di http://winbgim.codecutter.org/
 * http://www.cs.colorado.edu/~main/cs1300/doc/bgi/bgi.html
 * Kompilasi:
 * g++ ifs-bgi.c -o ifs-bgi.exe -mwindows -lbgi -lgdi32 
 * -lcomdlg32 -luuid -loleaut32 -lole32  
 */ 
#include "graphics.h"
#include <stdlib.h>
#include <stdio.h>

#define M 3  // jumlah titik pada objek awal
#define K 3  // jumlah transformasi

int ifs(int n, float x[], float y[], int l);

//transformasi {T1 , T2 ,  T3}
float a[K] = {0.5, 0.5, 0.5};
float b[K] = {0.0, 0.0, 0.0};
float c[K] = {0.0, 0.0, 0.0};
float d[K] = {0.5, 0.5, 0.5};
float e[K] = {0.0, 0.5, 0.0};
float f[K] = {0.0, 0.0, 0.5};
  
// titik2 objek {p1, p2, p3}
float xo[M] = {0.0, 1.0, 0.0};
float yo[M] = {0.0, 0.0, 1.0};

int mxcolor = getmaxcolor();

int main(int argc, char *argv[])
{
	int N = atoi(argv[1]);
	// variabel dan initialisasi autodetection dengan "DETECT" 
	int gdriver = DETECT, gmode, errorcode;
	int lmax, lx, ly;
	
	initgraph(&gdriver, &gmode, "");	// initialisasi graphics 
	errorcode = graphresult(); 				// Baca hasil inisialisasi
	if (errorcode != grOk) {					//
		printf("Graphics error: %s\n", grapherrormsg(errorcode));
		exit(1);	// keluar program
	}

	lx = getmaxx();
	ly = getmaxy();
	lmax = ly;
	if(lx<ly) lmax = lx;
  lmax = lmax - 50; //kurangi 50 supaya ada jarak dengan pingir gambar  
	setfillstyle(SOLID_FILL, WHITE);
	bar(0,0,getmaxx(),getmaxy());		// Kotak untuk Background
	setlinestyle(SOLID_LINE, 1, 3);
	srand(314159);

  // gambar fraktal
	ifs(N,xo,yo,lmax);

	getch();			// tunggu input dari keyboard sebelum
	closegraph(); // tutup graphics
	
	return 0;
}

int ifs(int n, float x[], float y[], int l)
{
	int i, j;
	float xt[K][M];
	float yt[K][M];
	
	if (n >= 1){
		
		for(i=0; i<M; i++){
			for(j=0; j<K; j++){
				xt[j][i] = a[j]*x[i] + b[j]*x[i] + e[j];
				yt[j][i] = c[j]*x[i] + d[j]*y[i] + f[j];
			}
		}
		for(j=0; j<K; j++){
			ifs(n-1, xt[j], yt[j], l);
		}			
	}else{
		i = rand()%mxcolor;
		setcolor(i);									// warna
		for(i=0; i<M-1; i++){
			line(l*x[i]+25,l*(1-y[i])+25,l*x[i+1]+25,l*(1-y[i+1])+25);// gambar garis
		}
		line(l*x[0]+25,l*(1-y[0])+25,l*x[M-1]+25,l*(1-y[M-1])+25);// gambar garis 0 ke M-1
	}
}
