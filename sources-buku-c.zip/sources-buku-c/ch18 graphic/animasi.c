
/* Circular Motion example */ 
#include <graphics.h>
#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <math.h>

int main(void)
{
   float x, y, theta, pi = 2.0*asin(1.0);
   /* request autodetection */
   int gdriver = DETECT, gmode, errorcode;
   int n, mx, my;
   int ic, jc;
   int i, j;
   
   /* initialize graphics and local variables */
   initgraph(&gdriver, &gmode, "");

   /* read result of initialization */
   errorcode = graphresult();
   if (errorcode != grOk) {  /* an error occurred */
      printf("Graphics error: %s\n", grapherrormsg(errorcode));
      printf("Press any key to halt:");
      getch();
      exit(1);               /* terminate with an error code */
   }

   mx = getmaxx();
   my = getmaxy();
   ic = mx/2;
   jc = my/2;
   
   setfillstyle(SOLID_FILL, getmaxcolor());
   bar(0, 0, mx, my);
   
   /* animation */
   n=0;
   while(1){
      n++;
      x = 100*cos(n*pi/50);
      y = 100*sin(n*pi/50);
   
      i = ic + x;
      j = jc + y;
      /* set fill pattern */
      setfillstyle(SOLID_FILL, BLUE);
      setcolor(BLUE);
      /* draw a filled ellipse */
      fillellipse(i, j, 20, 20);
      line(ic,jc,i,j);
      circle(ic,jc,100);
      
      // tunggu
      delay(100);
      /* set fill pattern */
      setfillstyle(SOLID_FILL, WHITE);
      setcolor(WHITE);
      /* draw a filled ellipse */
      fillellipse(i, j, 20, 20);
      line(ic,jc,i,j);
   }

   /* clean up */
   closegraph();

   return 0;
}

