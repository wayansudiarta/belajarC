/* alokasi-memori-idx2.c
 * alokasi komputer memori dimensi 2
 */

#include <stdio.h>
#include <stdlib.h>

#define nx 5
#define ny 6

// makro indeks dimensi 2
#define IDX(i1,i2,n1,n2) ((i1)*(n1)+(i2))

int main()
{
	int i, j;
	float *data;
	
	data = (float *) malloc((size_t)((nx*ny)*sizeof(float)));
	
	// isi array dengan nilai i + 0.1*j
	for(i = 0; i < nx; i++){
		for(j = 0; j < ny; j++){
			data[IDX(i,j,nx,ny)] = i + 0.1*j;
		}
	}

	// print nilai data[i][j]
	printf("Array %d x %d \n", nx, ny);
	for(i = 0; i < nx; i++){
		for(j = 0; j < ny; j++){
			printf("%f  ", data[IDX(i,j,nx,ny)]);
		}
		printf("\n");
	}

	// free memory
	free(data);
	
	return 0;
}

