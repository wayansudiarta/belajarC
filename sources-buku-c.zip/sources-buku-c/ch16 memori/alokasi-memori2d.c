/* alokasi-memori2d.c
 * alokasi komputer memori dimensi 2
 * modifikasi dari Kode Numerical Recipe in C
 * http://www.nrbook.com/a/bookcpdf.html
 */

#include <stdio.h>
#include <stdlib.h>
 
#define nx 3
#define ny 4

float **array2d(long int n1, long int n2);
void free_mem2d(float **m);

int main()
{
	int i, j;
	float **data;
	
	data = array2d(nx,ny);
	
	// isi array dengan nilai i + 0.1*j
	for(i = 0; i < nx; i++){
		for(j = 0; j < ny; j++){
			data[i][j] = i + 0.1*j;
		}
	}

	// print nilai data[i][j]
	printf("Array %d x %d \n", nx, ny);
	for(i = 0; i < nx; i++){
		for(j = 0; j < ny; j++){
			printf("%f  ", data[i][j]);
		}
		printf("\n");
	}

	// free memory
	free_mem2d(data);
	
	return 0;
}

// Alokasi array float m[0..(N-1)][0..(M-1)] 
float **array2d(long int n1, long int n2)
{
	long int i;
	float **m;

	// Alokasi pointer untuk baris 
	m	=	(float **) malloc((size_t)(n1*sizeof(float*)));
	if(!m) printf("Error 1: alokasi memori untuk baris\n");

	m[0] = (float *) malloc((size_t)((n1*n2)*sizeof(float)));
	if (!m[0]) printf("Error 2: alokasi memori untuk baris*kolom\n");

	//  
	for(i = 1; i < n1; i++) m[i] = m[i-1] + n2;

	// return pointer  
	return m;
}

// Free memory
void free_mem2d(float **m)
{
	free(m[0]);
	free(m);
}
