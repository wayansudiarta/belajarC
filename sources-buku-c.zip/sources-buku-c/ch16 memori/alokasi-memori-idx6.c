/* alokasi-memori-idx6.c
 * alokasi komputer memori untuk dimensi 6 
 */

#include <stdio.h>
#include <stdlib.h>
 
#define nx 2
#define ny 2
#define nz 2

// makro indeks dimensi 3
#define IDX(i1,i2,i3,i4,i5,i6,n1,n2,n3,n4,n5,n6) ((((((i1)*(n1)+(i2))*(n2)+(i3))*(n3)+(i4))*(n4)+(i5))*(n5)+(i6))

int main()
{
	long int i, j, k, i2, j2, k2, index;
	float *data;
	
	// alokasi memori
	data = (float *) malloc((size_t)((nx*ny*nz*nx*ny*nz)*sizeof(float)));
	
	// isi array 
	for(i = 0; i < nx; i++){
		for(j = 0; j < ny; j++){
			for(k = 0; k < nz; k++){
				for(i2 = 0; i2 < nx; i2++){
					for(j2 = 0; j2 < ny; j2++){
						for(k2 = 0; k2 < nz; k2++){
							index = IDX(i,j,k,i2,j2,k2,nx,ny,nz,nx,ny,nz);
							data[index] = i + 1E-1*j + 1E-2*k + 1E-3*i2 + 1E-4*j2 + 1E-5*k2;
						}
					}
				}
			}
		}
	}

	// print nilai data
	printf("Array %d x %d \n", nx, ny);
	// isi array 
	for(i = 0; i < nx; i++){
		for(j = 0; j < ny; j++){
			for(k = 0; k < nz; k++){
				for(i2 = 0; i2 < nx; i2++){
					for(j2 = 0; j2 < ny; j2++){
						for(k2 = 0; k2 < nz; k2++){
							index = IDX(i,j,k,i2,j2,k2,nx,ny,nz,nx,ny,nz);
							printf("%d  %d  %d  %d  %d  %d   %f \n", i, j, k, i2, j2, k2, data[index]);
						}
					}
				}
			}
		}
	}
	
	// free memory
	free(data);
	
	return 0;
}

