/* alokasi-memori-idx3.c
 *
 */

#include <stdio.h>
#include <stdlib.h>
 
#define nx 2
#define ny 3
#define nz 4

// makro indeks dimensi 3
#define IDX(i1,i2,i3,n1,n2,n3) (((i1)*(n1)+(i2))*(n2)+(i3))

int main()
{
	int i, j, k;
	float *data;
	
	data = (float *) malloc((size_t)((nx*ny*nz)*sizeof(float)));
	
	// isi array dengan nilai i + 0.1*j
	for(i = 0; i < nx; i++){
		for(j = 0; j < ny; j++){
			for(k = 0; k < nz; k++){
				data[IDX(i,j,k,nx,ny,nz)] = i + 0.1*j + 0.01*k;
			}
		}
	}

	// print nilai data[i][j]
	printf("Array %d x %d \n", nx, ny);
	for(i = 0; i < nx; i++){
		for(j = 0; j < ny; j++){
			for(k = 0; k < nz; k++){
				printf("%f  ", data[IDX(i,j,k,nx,ny,nz)]);
			}
			printf("\n");
		}
		printf("\n");
	}

	// free memory
	free(data);
	
	return 0;
}

