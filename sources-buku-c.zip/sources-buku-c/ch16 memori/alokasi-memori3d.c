/* alokasi-memori3d.c
 * alokasi komputer memori dimensi 3
 * modifikasi dari Kode Numerical Recipe in C
 * http://www.nrbook.com/a/bookcpdf.html
 */

#include <stdio.h>
#include <stdlib.h>
 
#define nx 2
#define ny 3
#define nz 4

float ***array3d(long int n1, long int n2, long int n3);
void free_mem3d(float ***m);

int main()
{
	int i, j, k;
	float ***data;
	
	data = array3d(nx, ny, nz);
	
	// isi array dengan nilai i + 0.1*j
	for(i = 0; i < nx; i++){
		for(j = 0; j < ny; j++){
			for(k = 0; k < nz; k++){
				data[i][j][k] = i + 0.1*j + 0.01*k;
			}
		}
	}

	// print nilai data[i][j]
	printf("Array %d x %d x %d\n", nx, ny, nz);
	for(i = 0; i < nx; i++){
		for(j = 0; j < ny; j++){
			for(k = 0; k < nz; k++){
				printf("%f  ", data[i][j][k]);
			}
			printf("\n");
		}
		printf("\n");
	}
	
	// free memory
	free_mem3d(data);
	
	return 0;
}

// Alokasi array float m[0..(n1-1)][0..(n2-1)][0...(n3-1)] 
float ***array3d(long int n1, long int n2, long int n3)
{
	long int i, j;
	float ***m;

	// Alokasi pointer untuk baris 
	m	=	(float ***) malloc((size_t)(n1*sizeof(float**)));
	if(!m) printf("Error 1: alokasi memori untuk baris\n");

	m[0]=(float **) malloc((size_t)((n1*n2)*sizeof(float*)));
	if (!m[0]) printf("Error 2: alokasi memori untuk baris*kolom\n");

  m[0][0]=(float *) malloc((size_t)((n1*n2*n3)*sizeof(float)));
	if (!m[0][0]) printf("Error 3: alokasi memori untuk baris*kolom*tebal\n");

	//  
	for(j = 1; j < n2; j++){ 
		m[0][j] = m[0][j-1] + n3;
	}
	for(i = 1; i < n1; i++) {
		m[i] = m[i-1] + n2;
		m[i][0] = m[i-1][0] + n2*n3;
		for(j = 1; j < n2; j++){ 
			m[i][j] = m[i][j-1] + n3;
		}
	}

	// return pointer to array 
	return m;
}

// Free memory
void free_mem3d(float ***m)
{
	free(m[0][0]);
	free(m[0]);
	free(m);
}
