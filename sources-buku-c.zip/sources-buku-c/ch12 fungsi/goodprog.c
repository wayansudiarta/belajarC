/*
	goodprog.c
	Memberikan contoh bagaimna membuat kode program khususnya pada fungsi
	dengan baik.
	
	Untuk kompilasi : gcc goodprog.c -o goodprog
	dan untuk menjalakanya : ./goodprog
*/
#include <stdio.h>

// (1) inti dari fungsinya sama bisa saja menggunakan nama yang sama
//	   untuk menghindari kesalahan lebih baik namanya dibedakan

// (2) Menggunakan jenis deklarasi fungsi dahulu, lalu diikuti defininya setelah fungsi main()
void junlah1(int *a);
int jumlah2(int b, int c, int d);

int main(){
	
	
	int a1[3] = {1,2,3};
	int b1 = 1, c1 = 2, d1 = 3;
	
	jumlah1(&a1);
	
	printf("\njumlah2 = %d",jumlah2(b1,c1,d1));
	
	return 0;
}

// untuk fungsi array lebih baik menggunakan pengiriman parameter dengan referensi
// call by reference
void jumlah1(int *a){
	
	int i, sum1 = 0;
	
	for(i = 0; i < 3; i++){
		
		sum1 += a[i];
	}
	
	printf("jumlah1 = %d\n",sum1);
}

int jumlah2(int b, int c, int d){
	
	int sum2;
	
	sum2 = b + c + d;
	
	return sum2 ;
}
