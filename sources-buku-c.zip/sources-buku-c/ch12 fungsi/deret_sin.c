/*
	deret_sin.c
	Membuat fungsi sinus dari deret taylor dengan bantuan fungsi 
	
	Untuk mengkopilasi kode program ini menggunakan perintah:
	gcc deret_sin.c -o deret_sin
	
	dan menjalakanya mengunakan cara :
	./deret_sin.exe
*/

#include<stdio.h>
#include<math.h>

//(1) Deklarasi fungsi faktorial
int fakto(int a); // prototype

int main(){
	
	double s = 0.0 ,sinus;
	long int n,u;
	int y;
	
	// (2) memasukan nilai y
	printf("Masukan nilai y untuk menghitung nilai sin(y) = ");
	scanf("%d",&y);
	
	// (3) proses perhitungan nilai sin(y) menggunakan deret taylor
	//     dan ada proses pemanggilan fungsi fakto() untuk faktorial.
	for(n=1;n<15;n+=2){
		
		if(((n+1)/2)%2==0) s=s-(double)pow(y,n)/(double)fakto(n) ;
		
		else s=s+(double)pow(y,n)/(double)fakto(n) ;		
	}
	
	//(4) Menampilkan hasil deret sin(y) dan dibandingakan dengan fungsi sin() pada lib math.h
	sinus = sin(y);
	printf("\nNilai sin(%ld) deret = %lf\n",y,s);
	
	printf("Nilai sin(%ld) fungsi= %lf",y,sinus);
	
	
	return 0;
}

// (5) Definisi fungsi fakto () sebagai pembantu dalam program ini
int fakto(int a){
	
	int x=1;
	int n;
	
	for(n=1;n<=a;n++){
		x=x*n;	
	}
	
	return x;
}
