#include <stdio.h>

int x=2; // variable global x

void limakalix(void); //prototype
void limakaliy(int y);

int main() { 

	int a = 2; //variabel lokal a
	
	limakalix(); // x*5 = 10
	
	limakaliy(a);
	
	return 0;

} 

void limakalix(void) {
	x *= 5 ;
 
	printf("limakali x (variabel global) = %d\n",x);
 
 }
void limakaliy(int y){
	y *= 5;
	
	printf("limakali a (variabel lokal) = %d",y);
}
