/*
	multistring.c
	Mrupakan suatu program menampilkan sebuah kata sebanyak yang kita inginkan dengan suatu fungsi
	
	Untuk kompilasi kode program ini dengan cara :
	gcc multistring.c -o multistring
	
	dan menjalakan program dengan cara :
	./multistring.exe

*/

#include<stdio.h>

// (1) deklrasi fungsi multidisplay
void multidisplay(char *word, int a); //prototype

int main(){
	
	
	int n;
	char kata[20];
	
	printf("Masukan Kata....\n");
	gets(kata);
	
	printf("\nMasukan jumlh perulangan kata...\n");
	scanf("%d",&n);
	
	// (2) memanggil fungsi yang telah dibuat
	multidisplay(kata,n);
		
	return 0;
}

//(3) definisi fungsi multidisplay()
void multidisplay(char *word, int a){
	
	int i;
	for (i = 0; i < a; i++){
		
		printf("\n");
		printf("%s",word);
	}
	
}
