/*
	fungsi1.c
	Program untuk belajar dasar mngenai fungsi
	yaitu deklarasi, definisi, dan cara pemanggilan parameter
	
	Untuk kompilasi kode program ini dengan cara:
	gcc fungsi1.c -o fungsi1
	
	dan untuk menjalankanya menggunakan perintah:
	./fungsi1.exe

*/

#include<stdio.h>

// (1) deklarasi prototype fungsi.
void tampilan(void);
int jumlah(int a, int b);
void bagidua(int a);

int main()
{
   int a = 4, b = 5, c;
   
   // (2) memanggil fungsi-fungsi.
   c = jumlah(a,b);
   tampilan();
   
   printf(" nilai a = %d \n", a);
   printf(" nilai b = %d \n", b);
   printf(" nilai jumlah(a,b) = %d \n", c);
   bagidua(a);
   
   return 0;
}

// (3) Definisi fungsi-fungsi.
void tampilan (void){
	
	printf("\n=============== SELAMAT DATANG DI PROGRAM C ===============\n\n");
}

int jumlah(int a, int b)
{
   return (a+b);
}

void bagidua(int a)
{
   printf(" nilai bagidua(a) = %d",a/2);
}
