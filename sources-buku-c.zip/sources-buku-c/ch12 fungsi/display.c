/*
	display.c
	Merupakan program menampilan suatu keluaran sederhana menggunakan fungsi
	
	Untuk kompilasinya dapat dilakukan dengan cara :
	gcc display.c -o display
	
	dan untuk menjalankanya menggunakan perintah:
	./display.exe

*/

#include<stdio.h>

// (1) deklarasi fungsi dengan prototype
void display (void);

int main(){
	
	// (2) memanggil fungsi display()
	display();
	
	return 0;	
}

// (3) definisi fungsi diplay berupa kelaran tulisan.
void display (void){
	
	int i,j,k;
	printf("\t===== Selamat Datang =====\n");
	
	printf("\t===== Belajar Bahasa C =====\n\n");
	
	for (i = 0; i <= 10; i++){
		
		for(j = 1; j <= i; j++){
			
			printf("* ");
				
		}
		
		printf("\n");
	}
	
	for (k = 10; k >= 0; k--){
		
		for(j = 1; j <= k; j++){
			
			printf("* ");
				
		}
		
		printf("\n");
	}
}

