/*
	std_dev-func.c
	Merupakan untuk menghitung standar deviasi suatu masukan dengan fungsi
	
	Source = http://www.sanfoundry.com/c-programming-examples.
	 
	Untuk kompilasi kode progrm ini menggunakan perintah:
	gcc std_dev-func.c -o std_dev-func
	
	dan menjalakan program ini menggunakan cara:
	./std_dev-func.exe
*/

#include<stdio.h>
#include<math.h>

// (1) deklarasi fungsi stddev
void stddev(float *file); // prototype

int main(){
	
	float data[10];
	int i;
	
	// (2) meminta masukan data
	printf("Masukan data...\n");
	
	for(i = 0; i < 10; i++){
		
		scanf("%f", &data[i]);
	}
	
	printf("\ndata yang dimasukan...\n\n");
	printf("data = ");
	for(i = 0; i < 10; i++){
		
		printf(" %.2f ",data[i]);
	}
	
	// (3) memanggil fungsi stddev
	stddev(&data);
	
	return 0;
}

//(4) definis fungsi stddev()
void stddev(float *file){
	
	int i,j;
	float rata, jumlh = 0.0, sd = 0.0;
	
	for(i = 0; i < 10; i++){
		jumlh += file[i];
	}
	
	rata = (jumlh/10.0);
	
	for(i=0;i < 10; i++){
		
		sd += pow((file[i]-rata), 2);
	}
	
	sd = sqrt(sd/(10-1));
	
	printf("\n\nStandar Deviasi data = %.2f",sd);
}
