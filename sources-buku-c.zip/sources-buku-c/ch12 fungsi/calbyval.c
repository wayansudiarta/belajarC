#include<stdio.h>

void limakali(double x); //prototype
 
int main() 
{ 
   double a = 2; 
   
   printf("Nilai a sebelum fungsi : %.2lf\n",a);
   limakali(a);
   printf("\nNilai a setelah fungsi : %.2lf\n",a);
   
   
} 

void limakali(double x){ 
	
	x *= 5.0;
	printf("\nNilai a pada fungsi : %.2lf\n",x);
	
}
