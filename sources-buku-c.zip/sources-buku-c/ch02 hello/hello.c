/* hello.c
	Menampilkan text "Hello World!!!"
	Kompilasi: 
		gcc hello.c -o hello.exe
	Run: 
		./hello2.exe 
	Output:
		Hello World!!!
*/

#include<stdio.h>

int main()
{
	// tampilkan pada layar
	printf(" Hello World!!!\n");

	return 0;
}
