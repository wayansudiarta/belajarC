/* Program hello2.c
	Menampilkan text "Hello [NamaProgrammer]!"
	dengan input [NamaProgrammer] dari 
	command prompt
	Kompilasi: 
		gcc hello2.c -o hello2.exe
	Run: 
		./hello2.exe Wayan
	Output:
		Hello Wayan!
*/

#include<stdio.h>

int main(int argc, char *argv[])
{
	// tampilkan pada layar
	printf(" Hello %s !\n", argv[1]);

	return 0;
}