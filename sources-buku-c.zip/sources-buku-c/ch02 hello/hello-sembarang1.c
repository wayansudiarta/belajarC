/* Program hello.c
   Menampilkan text " Hello World !!!"
*/ #include<stdio.h>
int main(){  // tampilkan pada layar
printf(" Hello World !!!\n"); return 0;}
