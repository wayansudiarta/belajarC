/* contoh-pointer-array.c 
 * Penggunaan pointer pada array
 * gcc contoh-pointer-array.c -o contoh-pointer-array.exe
 */

#include<stdio.h>

int main()
{
	int *p, b[5];

	b[0] = 0; // beri nilai sesuai indeks
	b[1] = 1;
	b[2] = 2;
	b[3] = 3;
	b[4] = 4;
      
	p = b; // p menunjuk ke alamat b[0]
					// dapat juga ditulis dengan p = &b[0];
	printf("Nilai variabel ditunjuk oleh p = %d\n",*p);

	p = p + 1; // p menunjuk ke alamat b[1] 
	printf("Nilai variabel ditunjuk oleh p = %d\n",*p);

	p--; // kembali ke alamat b[0]
	printf("Nilai variabel ditunjuk oleh p = %d\n",*p);

	p = p + 3; // p menunjuk ke alamat b[3]
	printf("Nilai variabel ditunjuk oleh p = %d\n",*p);
	
	p = &b[0]; // p menunjuk ke alamat b[0]
	*(p +1) = 123; // b[1] = 123
	printf("Nilai variabel b[1] = %d\n",*(p+1));

	p[4] = 321; // b[4] = 321
	printf("Nilai variabel b[4] = %d\n",p[4]);
	
	return 0;
}
