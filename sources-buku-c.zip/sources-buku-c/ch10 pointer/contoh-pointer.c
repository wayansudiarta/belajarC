/* contoh-pointer.c 
 * gcc contoh-pointer.c -o contoh-pointer.exe
 */

#include<stdio.h>

int main()
{
	float a;  // variabel tipe float
	float *p; // sebuah pointer tipe float

	a = 2.3;  // beri nilai a = 2.3;  
	p = &a;   // variabel p diisi dengan 
             // alamat variabel a
   
	printf("Nilai  a = %f \n", a);
	printf("Alamat a = %p \n", p);  

	*p = 4.2; // kita ubah nilai variabel a
   
	printf("Nilai a = %f \n", a);

	return 0;
}