/* size-tipedata.c
	 Program untuk mengetahui ukuran memori
	 untuk beberapa tipe data
	 fungsi yang digunakan adalah sizeof()
 */

#include<stdio.h>

int main()
{
  printf("\n\t===============================\n");
	printf("\t| Tipe Data   | Ukuran Memori |\n");
	printf("\t==============|================\n");
  printf("\t| char        |     %3d byte  |\n", sizeof(char));
  printf("\t| int         |     %3d bytes |\n", sizeof(int));
  printf("\t| short       |     %3d bytes |\n", sizeof(short));
  printf("\t| long        |     %3d bytes |\n", sizeof(long));
  printf("\t| float       |     %3d bytes |\n", sizeof(float));
  printf("\t| double      |     %3d bytes |\n", sizeof(double));
  printf("\t| long double |     %3d bytes |\n", sizeof(long double));
  printf("\t===============================\n");
	
	return 0;
}
