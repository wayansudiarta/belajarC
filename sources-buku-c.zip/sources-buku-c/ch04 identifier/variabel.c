// Deklarasi variabel

#include<stdio.h>

int main()
{
   int a, b, c;     // tipe integer
   int c = 34;      // inisialisasi variabel
   float f, g, h;   // tipe float 
   char z = 'P';    // tipe character, huruf
   
   a = 2;
   b = a + c;
  
   f = 4.2;
   g = 9.0;
     
   f = f + g;
   g = f/g;
   
   h = a/b;
   
   printf("Nilai b = %d\n", b);
   printf("Nilai f = %f\n", f);
   printf("Nilai h = %f\n", h);
   
   return 0;
}
